Ohio-County-JVectorMap
========================

An svg map file of ohio counties configured via JVectorMap (http://jvectormap.com/) 


Feel free to use the map. I am not taking credit for the great Jquery plugin associated with this repo.

PLEASE CONSULT THE PLUGIN'S WEBSITE FOR THE RULES, LICENSING, AGREEMENTS, AND ANY OTHER LEGAL CONCERNS. 
I WILL NOT BE RESPONSIBLE FOR ANY MISUSE OF THE PLUGIN.
